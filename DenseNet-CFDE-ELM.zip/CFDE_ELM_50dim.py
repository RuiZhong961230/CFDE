import sys
import hpelm
import numpy as np
import torch
from sklearn.metrics import accuracy_score, f1_score, recall_score
from torch import optim, nn
import torchvision
from pokemon0 import Pokemon
import os
from utils import Flatten
from mealpy import FloatVar
import pickle


def evalute(model, loader):
    model.eval()

    correct = 0
    total = len(loader.dataset)
    total_val =0
    for x, y in loader:
        x, y = x.to(device), y.to(device)
        with torch.no_grad():
            logits = model(x)
            pred = logits.argmax(dim=1)
        total_val += y.size(0)
        correct += torch.eq(pred, y).sum().float().item()
# y.size(0)
    return correct / total

def get_evaluate_acc_pred(model, loader):
    model.eval()

    correct = 0
    total = len(loader.dataset)
    total_val = 0
    predictions = []  # 存储所有的预测结果

    for x, y in loader:
        x, y = x.to(device), y.to(device)
        with torch.no_grad():
            logits = model(x)
            pred = logits.argmax(dim=1)
            predictions.extend(pred.cpu().numpy())  # 将预测值转换为 numpy 数组并添加到列表中

        total_val += y.size(0)
        correct += torch.eq(pred, y).sum().float().item()

    accuracy = correct / total
    return accuracy, predictions
def getevaluteY(model, loader):
    pre_Y = []
    Y = []
    model.eval()

    correct = 0
    total = len(loader.dataset)
    
    for x, y in loader:
        x, y = x.to(device), y.to(device)
        with torch.no_grad():
            logits = model(x)
            pred = logits.argmax(dim=1)
            # 将预测的Y和实际的Y追加到列表中
            pre_Y.extend(pred.cpu().numpy())
            Y.extend(y.cpu().numpy())
        correct += torch.eq(pred, y).sum().float().item()

    return pre_Y, Y
import random
def set_seed(seed):
    random.seed(seed)                       # 设置Python的随机种子
    np.random.seed(seed)                    # 设置NumPy的随机种子
    torch.manual_seed(seed)                 # 设置PyTorch的CPU随机种子
    torch.cuda.manual_seed(seed)            # 设置当前GPU的随机种子（如果使用GPU）
    torch.cuda.manual_seed_all(seed)        # 设置所有GPU的随机种子（如果使用多个GPU）
    torch.backends.cudnn.deterministic = True  # 确保每次卷积操作结果一致
    torch.backends.cudnn.benchmark = False
from torch.utils.data import DataLoader, SubsetRandomSampler
import random


# 训练新的模型
def generativeModel():
    global device, x_train, y_train

    # Set the seed for reproducibility
    

    lr = 1e-3
    epochs = 1
    num_cuda_devices = torch.cuda.device_count()
    print(f"当前系统上有 {num_cuda_devices} 个可用的CUDA设备。")

    # 指定要使用的CUDA设备
    desired_device_id = 0  # 选择要使用的设备的ID
    if desired_device_id < num_cuda_devices:
        torch.cuda.set_device(desired_device_id)
        print(f"已将CUDA设备切换到设备ID为 {desired_device_id} 的设备。")
    else:
        print(f"指定的设备ID {desired_device_id} 超出可用的CUDA设备数量。")
    device = torch.device('cuda:0')
    parent_dir = os.path.dirname(os.getcwd())
    # 获取当前脚本文件的绝对路径
    script_path = os.path.abspath(__file__)
    # 获取当前脚本文件的父文件夹
    cwd_dir = os.path.dirname(script_path)

    

    
    model_name = ["densenet169_model"]
    for index in range(0,1):
                    
        
        val_acc_Trial = np.zeros((5, epochs))
        train_acc_Trial = np.zeros((5, epochs))
        val_loss_Trial = np.zeros((5, epochs))
        train_loss_Trial = np.zeros((5, epochs))
        test_acc_list=np.zeros((5, 1))
        for ii in range(0, 5):  
            set_seed(42+index+ii )
            if model_name[index]=="densenet169_model":
                # Load the pretrained DenseNet169 model
                densenet169_model = torchvision.models.densenet169(pretrained=False)
                densenet169_model = nn.Sequential(
                    *list(densenet169_model.children())[:-1],  # Extract all layers except the classifier
                    nn.AdaptiveAvgPool2d(1),  # Global Average Pooling to reduce the spatial dimensions
                    nn.Flatten(),  # Flatten the output to [b, 1664]
                    nn.Linear(1664, 50),  # Add custom classification layer for 4 output classes
                    nn.ReLU(),
                    nn.Linear(50, 4)
                ).to(device)
                model=densenet169_model

            else:
                pass
            
            print(f"执行模型{model_name[index]}:第{ii}次 -------------")
            filemame = f"images{0}.csv"
            if model_name[index] == "vit_model":
                train_db = Pokemon(cwd_dir + '/data', filemame, 224, mode='train')
                val_db = Pokemon(cwd_dir + '/data', filemame, 224, mode='val')
                test_db = Pokemon(cwd_dir + '/data', filemame, 224, mode='test')
            else:
                train_db = Pokemon(cwd_dir + '/data', filemame, 299, mode='train')
                val_db = Pokemon(cwd_dir + '/data', filemame, 299, mode='val')
                test_db = Pokemon(cwd_dir + '/data', filemame, 299, mode='test')
                       

            # Create indices and random sampler
            indices = np.arange(len(train_db))
            indices1 = np.arange(len(val_db))
            indices2 = np.arange(len(test_db))
            # Use SubsetRandomSampler with a random seed
            sampler = SubsetRandomSampler(indices )
            sampler1 = SubsetRandomSampler(indices1)
            sampler2 = SubsetRandomSampler(indices2)

            # 假设 train_db, val_db, test_db 是你已经定义好的数据集
            batchsz = 10

            # 在DataLoader中设置generator参数
            train_loader = DataLoader(train_db, batch_size=batchsz, sampler=sampler)
            val_loader = DataLoader(val_db, batch_size=batchsz, shuffle=False)
            test_loader = DataLoader(test_db, batch_size=batchsz, shuffle=False)

            optimizer = optim.Adam(model.parameters(), lr=lr)
            criteon = nn.CrossEntropyLoss()

            best_acc, best_epoch = 0, 0
            global_step = 0
            
            for epoch in range(epochs):
                correct_train = 0  # 用于计算训练集上的准确率
                total_train = 0  # 训练样本总数
                train_loss = 0  # 用于计算训练集损失

                for step, (x, y) in enumerate(train_loader):
                    # x: [b, 3, 224, 224], y: [b]
                    x, y = x.to(device), y.to(device)

                    model.train()
                    logits = model(x)
                    loss = criteon(logits, y)
                    optimizer.zero_grad()
                    loss.backward()
                    optimizer.step()

                    # 累加训练损失
                    train_loss += loss.item()


                    _, preds = torch.max(logits, 1)  # 获取每个样本的预测标签
                    correct_train += (preds == y).sum().item()
                    total_train += y.size(0)  # 累加样本数量

                    global_step += 1

                # 计算当前 epoch 的训练集平均损失和准确率
                train_acc = correct_train / total_train
                avg_train_loss = train_loss / len(train_loader)

                # 验证阶段
                model.eval()
                val_loss = 0
                correct_val = 0
                total_val = 0

                with torch.no_grad():
                    for val_x, val_y in val_loader:
                        val_x, val_y = val_x.to(device), val_y.to(device)

                        logits = model(val_x)

                        loss = criteon(logits, val_y)

                        # 累加验证集损失
                        val_loss += loss.item()

                        # 计算验证集准确率
                        _, val_preds = torch.max(logits, 1)
                        correct_val += (val_preds == val_y).sum().item()
                        total_val += val_y.size(0)

                # 计算验证集的平均损失和准确率
                avg_val_loss = val_loss / len(val_loader)
                val_acc = correct_val / total_val

                # 存储准确率和损失
                val_acc_Trial[ii, epoch] = val_acc
                train_acc_Trial[ii, epoch] = train_acc
                val_loss_Trial[ii, epoch] = avg_val_loss
                train_loss_Trial[ii, epoch] = avg_train_loss

                if epoch % 1 == 0:

                    # val_acc = evalute(model, val_loader)
                    if val_acc > best_acc:
                        best_epoch = epoch
                        best_acc = val_acc
                        dirp = cwd_dir
                        if os.path.exists(os.path.join(dirp,model_name[index],str(epochs),"50dim")) == False:
                            os.makedirs(os.path.join(dirp,model_name[index],str(epochs),"50dim"))
                        torch.save(model.state_dict(), f'{dirp}/{model_name[index]}/{str(epochs)}/50dim/best{ii}.mdl')

                print("epoch:", {epoch}, ":best_acc", {best_acc})
                # 打印当前 epoch 的结果
                print(f"Epoch [{epoch}/{epochs}] - "
                      f"Train Loss: {avg_train_loss:.4f}, Train Acc: {train_acc:.4f}, "
                      f"Val Loss: {avg_val_loss:.4f}, Val Acc: {val_acc:.4f}") 
            
            np.savetxt(f'{dirp}/{model_name[index]}/{str(epochs)}/50dim/' + "train_acc.csv", train_acc_Trial, delimiter=",")

            np.savetxt(f'{dirp}/{model_name[index]}/{str(epochs)}/50dim/' + "val_acc.csv", val_acc_Trial, delimiter=",")

            np.savetxt(f'{dirp}/{model_name[index]}/{str(epochs)}/50dim/' + "val_loss.csv", val_loss_Trial, delimiter=",")

            np.savetxt(f'{dirp}/{model_name[index]}/{str(epochs)}/50dim/' + "train_loss.csv", train_loss_Trial, delimiter=",")
            # print(np.array(val_acc_Trial).reshape(1, -1))
            print('best acc:', best_acc, 'best epoch:', best_epoch)

            model.load_state_dict(torch.load(f'{dirp}/{model_name[index]}/{str(epochs)}/50dim/best{ii}.mdl'))
            print('loaded from ckpt!')

            test_acc = evalute(model, test_loader)
            test_acc_list[ii]=test_acc
            
            print('test acc:', test_acc)

                
                
               


from collections import defaultdict


def default_dict_factory():
    return defaultdict(dict)


from scipy.stats import cauchy
from copy import deepcopy
  
PopSize =100
DimSize = 4
LB =[10, 2, 2, 1]
UB =[300, 20, 20, 10] 
TrialRuns = 1
MaxFEs =100*30
curFEs = 0
curIter = 0
Pop = np.zeros((PopSize, DimSize))
FitPop = np.zeros(PopSize)

FuncNum = 0
Length = 10
muF = np.random.uniform(0.1, 0.9, Length)
muCr = np.random.uniform(0.1, 0.9, Length)
elm = hpelm.ELM(50, 4)

def meanL(arr):
    numer = 0
    denom = 0
    for var in arr:
        numer += var ** 2
        denom += var
    return numer / denom


def Check(indi):
    global LB, UB
    for i in range(DimSize):
        range_width = UB[i] - LB[i]
        if indi[i] > UB[i]:
            n = int((indi[i] - UB[i]) / range_width)
            mirrorRange = (indi[i] - UB[i]) - (n * range_width)
            indi[i] = UB[i] - mirrorRange
        elif indi[i] < LB[i]:
            n = int((LB[i] - indi[i]) / range_width)
            mirrorRange = (LB[i] - indi[i]) - (n * range_width)
            indi[i] = LB[i] + mirrorRange
        else:
            pass
    return indi


def Initialization(func):
    global Pop, FitPop, curFEs, DimSize, muF, muCr, Length,UB,LB,elm
    Pop = np.zeros((PopSize, DimSize))
    for i in range(PopSize):
        for j in range(DimSize):
            Pop[i][j] = LB[j] + (UB[j] - LB[j]) * np.random.rand()
        FitPop[i], elm= func(Pop[i])
    muF = np.random.uniform(0.1, 0.9, Length)
    muCr = np.random.uniform(0.1, 0.9, Length)

def CFDE(func):
    global Pop, FitPop, curFEs, LB, UB, PopSize, DimSize, muF, muCr,elm
    F_List, Cr_List = [], []
    Seq = list(range(PopSize))
    np.random.shuffle(Seq)
    c = 0.1
    sigma = 0.1

    idxF, idxCr = np.random.randint(Length), np.random.randint(Length)

    for i in range(int(PopSize / 2)):

        idx1, idx2 = Seq[2 * i], Seq[2 * i + 1]
        F = cauchy.rvs(muF[idxF], sigma)
        while True:
            if F > 1:
                F = 1
                break
            elif F < 0:
                F = cauchy.rvs(muF[idxF], sigma)
            break
        Cr = np.clip(np.random.normal(muCr[idxCr], sigma), 0, 1)
        jrand = np.random.randint(DimSize)

        if FitPop[idx1] <= FitPop[idx2]:
            Off = Pop[idx2] + F * (Pop[np.argmin(FitPop)] - Pop[idx2]) + F * (Pop[idx1] - Pop[idx2])
            for j in range(DimSize):
                if np.random.rand() < Cr or j == jrand:
                    pass
                else:
                    Off[j] = Pop[idx2][j]
            Off = Check(Off)
            FitOff,tempelm = func(Off)
            curFEs += 1
            if FitOff < FitPop[idx2]:
                FitPop[idx2] = FitOff
                Pop[idx2] = deepcopy(Off)
                F_List.append(F)
                Cr_List.append(Cr)
        else:
            Off = Pop[idx1] + F * (Pop[np.argmin(FitPop)] - Pop[idx1]) + F * (Pop[idx2] - Pop[idx1])
            for j in range(DimSize):
                if np.random.rand() < Cr or j == jrand:
                    pass
                else:
                    Off[j] = Pop[idx1][j]
            Off = Check(Off)
            FitOff,tempelm = func(Off)
            curFEs += 1
            if FitOff < FitPop[idx1]:
                FitPop[idx1] = FitOff
                Pop[idx1] = deepcopy(Off)
                F_List.append(F)
                Cr_List.append(Cr)
        if FitOff<min(FitPop):
            elm=tempelm

    if len(F_List) == 0:
        pass
    else:
        muF[idxF] = (1 - c) * muF[idxF] + c * meanL(F_List)
    if len(Cr_List) == 0:
        pass
    else:
        muCr[idxCr] = (1 - c) * muCr[idxCr] + c * np.mean(Cr_List)

# 直接读取生成模型的参数，直接预测
# elm=None
def main():
    import numpy as np
    global x_train, y_train, x_val, y_val, device, TZnum, concatenate_x_train, concatenate_y_train, tag, test, test_y, dim
    # batchsz = 30
    lr = 1e-3

    device = torch.device('cuda:0')
    parent_dir = os.path.dirname(os.getcwd())
    # 获取当前脚本文件的绝对路径
    script_path = os.path.abspath(__file__)
    # 获取当前脚本文件的父文件夹
    cwd_dir = os.path.dirname(script_path)
    tag = 0  # 如果不合并训练集和验证集就为0，否则为1,交叉验证
    
    result = defaultdict(default_dict_factory)

     


    model_name = [ "densenet169_model"]
    # model_name = [ "alexnet_model"]
    epochs=1 #加载运行了epochs的模型
    for index  in range(len(model_name)): 
        
        All_Trial_Best = []
        elm_acc = []

        for ii in range(0, 5):
            # seed = 42        
            # set_seed(seed)
            # torch.set_num_threads(1)
            set_seed(42+index+ii )
            if model_name[index]=="densenet169_model":
                # Load the pretrained DenseNet169 model
                densenet169_model = torchvision.models.densenet169(pretrained=False)
                densenet169_model = nn.Sequential(
                    *list(densenet169_model.children())[:-1],  # Extract all layers except the classifier
                    nn.AdaptiveAvgPool2d(1),  # Global Average Pooling to reduce the spatial dimensions
                    nn.Flatten(),  # Flatten the output to [b, 1664]
                    nn.Linear(1664, 50),  # Add custom classification layer for 4 output classes
                    nn.ReLU(),
                    nn.Linear(50, 4)
                ).to(device)
                model=densenet169_model
            else:
                pass
            

            filemame = f"images{0}.csv"
            # set_seed(42+index+ii )
            if model_name[index] == "vit_model":
                    train_db = Pokemon(cwd_dir + '/data', filemame, 224, mode='train')
                    val_db = Pokemon(cwd_dir + '/data', filemame, 224, mode='val')
                    test_db = Pokemon(cwd_dir + '/data', filemame, 224, mode='test')
            else:
                train_db = Pokemon(cwd_dir + '/data', filemame, 299, mode='train')
                val_db = Pokemon(cwd_dir + '/data', filemame, 299, mode='val')
                test_db = Pokemon(cwd_dir + '/data', filemame, 299, mode='test')
        

            # Create indices and random sampler
            indices = np.arange(len(train_db))
            indices1 = np.arange(len(val_db))
            indices2 = np.arange(len(test_db))
            # Use SubsetRandomSampler with a random seed
            sampler = SubsetRandomSampler(indices)
            sampler1 = SubsetRandomSampler(indices1)
            sampler2 = SubsetRandomSampler(indices2)

            # 假设 train_db, val_db, test_db 是你已经定义好的数据集
            batchsz =10

            # 在DataLoader中设置generator参数
            train_loader = DataLoader(train_db, batch_size=batchsz,  sampler=sampler)
            val_loader = DataLoader(val_db, batch_size=batchsz, shuffle=False)
            test_loader = DataLoader(test_db, batch_size=batchsz, shuffle=False)
             
            # 加载已经训练好的模型的值
            model.load_state_dict(torch.load(f'{cwd_dir}/{model_name[index]}/{str(epochs)}/50dim/best{ii}.mdl'))
            



            # 存储生成的特征的路径，下次get_features就直接读取现成的特征文件
            file_path = os.path.join(cwd_dir, f'data/x_train{ii}_{model_name[index]}_50dim.pkl')
            file_path1 = os.path.join(cwd_dir, f'data/y_train{ii}_{model_name[index]}_50dim.pkl')
            file_path2 = os.path.join(cwd_dir, f'data/x_val{ii}_{model_name[index]}_50dim.pkl')
            file_path3 = os.path.join(cwd_dir, f'data/y_val{ii}_{model_name[index]}_50dim.pkl')
            file_path4 = os.path.join(cwd_dir, f'data/test{ii}_{model_name[index]}_50dim.pkl')
            file_path5 = os.path.join(cwd_dir, f'data/test_y{ii}_{model_name[index]}_50dim.pkl')
            # file_path6 = os.path.join(cwd_dir, f'data/concatenate_x_train{ii}.pkl')
            # file_path7 = os.path.join(cwd_dir, f'data/concatenate_y_train{ii}.pkl')

            # 获取训练，验证数据和测试数据
            train, train_y = get_features(model, train_loader, file_path, file_path1,model_name[index])
            val, val_y = get_features(model, val_loader, file_path2, file_path3,model_name[index])
            test, test_y = get_features(model, test_loader, file_path4, file_path5,model_name[index])

            # 不合并训练集和验证集
            x_train = train
            y_train = train_y
            x_val, y_val = val, val_y


            # 如果提取的特征和标签不存在则保存，省的下次重新提取
            if not os.path.exists(file_path):
                with open(file_path, 'wb') as file:
                    pickle.dump(x_train, file)
            if not os.path.exists(file_path1):
                with open(file_path1, 'wb') as file:
                    pickle.dump(y_train, file)
            if not os.path.exists(file_path2):
                with open(file_path2, 'wb') as file:
                    pickle.dump(x_val, file)
            if not os.path.exists(file_path3):
                with open(file_path3, 'wb') as file:
                    pickle.dump(y_val, file)
            if not os.path.exists(file_path4):
                with open(file_path4, 'wb') as file:
                    pickle.dump(test, file)
            if not os.path.exists(file_path5):
                with open(file_path5, 'wb') as file:
                    pickle.dump(test_y, file)
            if tag == 1:  # 代表合并训练集和验证集
                concatenate_x_train = np.concatenate([x_train, x_val])
                concatenate_y_train = np.concatenate([y_train, y_val])


            import hpelm
            from keras.datasets import mnist
            from keras.utils import to_categorical
            import numpy as np
            from sklearn.metrics import accuracy_score
            # 生成onehot标签供elm训练
            y_train = to_categorical(y_train, 4)
            y_test = to_categorical(test_y, 4)
            y_val = to_categorical(val_y, 4)


            global d, n, m,elm
            d =10
            n = 50  # Input dimension 
            m = 4  # Output dimension
            num_neurons = 100  # Number of neurons

            # Calculate total dimensions: weights + biases
            dimensions = int(d * n) * n + int(d * n)

            lb = np.zeros(dimensions)
            # lb = np.zeros(dimensions)
            # lb = -1*np.ones(dimensions)
            ub = np.ones(dimensions)


            # Problem setup for PSO optimization
            problem_normal = {
                "obj_func": objective_functionELM,
                "bounds": FloatVar(lb, ub),
                "minmax": "min",
                "log_to": "console",
            }
            from sklearn.preprocessing import StandardScaler, MinMaxScaler
            scaler = StandardScaler()
            x_train = scaler.fit_transform(x_train)
            x_val = scaler.transform(x_val)
            test = scaler.transform(test)
            global curFEs, curFEs, TrialRuns, Pop, FitPop, DimSize,LB,UB
            DimSize = dimensions
            LB =lb
            UB =ub
            import sys

            # 确保输出到标准输出而不是关闭的文件
            sys.stdout = sys.__stdout__
            # elm = hpelm.ELM(n, m)
            # elm.add_neurons(int(d * n), "sigm")

            for i in range(TrialRuns):
                Best_list = []
                curFEs = 0
                # np.random.seed(1996 + 30 * i)
                Initialization(objective_functionELM)
                Best_list.append(min(FitPop))
                while curFEs < MaxFEs:
                    CFDE(objective_functionELM)
                    Best_list.append(min(FitPop))
                    print("bestfit=", min(FitPop))
                All_Trial_Best.append(Best_list)


            val_y_pred=elm.predict(x_val)
            val_acc = accuracy_score(np.argmax(y_val, axis=1), np.argmax(val_y_pred, axis=1))
            # 预测结果
            y_pred = elm.predict(test)  # 假设X是输入数据
            # 计算准确率
            acc = accuracy_score(np.argmax(y_test, axis=1), np.argmax(y_pred, axis=1))
            
            elm_acc.append(acc)
            result[f"CFDE_{model_name[index]}_ELM"]["test"][f"preY{ii}"] = np.argmax(y_pred, axis=1)
            result[f"CFDE_{model_name[index]}_ELM"]["test"][f"Y{ii}"] = test_y
            result[f"CFDE_{model_name[index]}_ELM"]["test"]["accuracy"] = acc

            result[f"CFDE_{model_name[index]}_ELM"]["val"][f"preY{ii}"] = np.argmax(val_y_pred,axis=1)
            result[f"CFDE_{model_name[index]}_ELM"]["val"][f"Y{ii}"] = val_y
            result[f"CFDE_{model_name[index]}_ELM"]["val"]["accuracy"] = val_acc

            print(f"CFDE_{model_name[index]}_ELM test=:", acc)
            val_acc,val_pred_y0 = get_evaluate_acc_pred(model, val_loader)
            test_acc ,test_pred_y0= get_evaluate_acc_pred(model, test_loader)

            result[f"{model_name[index]}"]["val"][f"preY{ii}"] = val_pred_y0
            result[f"{model_name[index]}"]["val"][f"Y{ii}"] = val_y
            result[f"{model_name[index]}"]["val"]["accuracy"] = val_acc

            result[f"{model_name[index]}"]["test"][f"preY{ii}"] = test_pred_y0
            result[f"{model_name[index]}"]["test"][f"Y{ii}"] = test_y
            result[f"{model_name[index]}"]["test"]["accuracy"] = test_acc

            # train_acc = evalute(model, train_loader)

            print("test_acc:",test_acc,";val_acc:",val_acc)
            with open(f"{cwd_dir}/CFDE_output_50dim_re.txt", "a") as f:
                sys.stdout = f  # 临时重定向标准输出
                print(f"{model_name[index]}:test_acc={test_acc}")                 
                print(f"{model_name[index]}:val_acc={val_acc}")
                print(f"CFDE_{model_name[index]}_ELM test=:",acc)
            sys.stdout = sys.__stdout__
        np.savetxt(f"{cwd_dir}/CFDE/CFDE_{model_name[index]}" + "_" + str(DimSize) + "dim.csv", All_Trial_Best,
               delimiter=",")
    result_dict = convert_defaultdict_to_dict(result)
    # 存储数据到result
    with open(f"{cwd_dir}/CFDE_acc.pkl", 'wb') as file:
        pickle.dump(result_dict, file)


def convert_defaultdict_to_dict(d):
    if isinstance(d, defaultdict):
        return {k: convert_defaultdict_to_dict(v) for k, v in d.items()}
    else:
        return d


def objective_functionELM(particle):
    global d, n, m
    global x_train, y_train, x_val, y_val,  dim

    W = particle[:int(d * n) * n].reshape(int(d * n), n)  # 假设有d*n个sigm神经元
    B = particle[int(d * n) * n:int(d * n) * n + int(d * n)].reshape(int(d * n), 1)  # 假设有d*n个sigm神经元
    elm0 = hpelm.ELM(n, m)
    # 添加一些神经元，指定激活函数
    elm0.add_neurons(int(d * n), "sigm")
    # 设置ELM的权重和阈值
    elm0.W = W
    elm0.B = B
    
    C=particle[-1]
    elm0.train(x_train, y_train,C=C)
    # 预测结果
    y_pred = elm0.predict(x_val)  # 假设X是输入数据

    acc = accuracy_score(np.argmax(y_val,axis=1), np.argmax(y_pred, axis=1))
    y = np.argmax(y_val, axis=1)
    y_pred = np.argmax(y_pred, axis=1)
    f1 = f1_score(y, y_pred, average='weighted')
    re = recall_score(y, y_pred, average='weighted')
    acc = acc
    # 返回误差值
    return -1 * acc,elm0


# get_features如果路径文件已经存在则读取后直接返回，否则提取model的特征和lable
def get_features0(model, train_loader, x_path, y_path):
    global device
    if (not os.path.exists(x_path)) or (not os.path.exists(y_path)):

        model0 = nn.Sequential(*list(model.children())[:-1],  # [b, 512, 1, 1]
                               Flatten(),  # [b, 512, 1, 1] => [b, 512]
                               ).to(device)
        model0.eval()

        for step, (x, y) in enumerate(train_loader):
            x, y = x.to(device), y.to(device)
            with torch.no_grad():
                features = model0(x)
                if step == 0:
                    result = features
                    result_y = y;
                else:
                    result = torch.cat([result, features], dim=0)
                    result_y = torch.cat([result_y, y], dim=0)
        result, result_y = result.cpu(), result_y.cpu()
        with open(x_path, 'wb') as file:
            pickle.dump(result, file)
        with open(y_path, 'wb') as file:
            pickle.dump(result_y, file)

        return result.numpy(), result_y.numpy()
    else:
        with open(x_path, 'rb') as file:
            result = pickle.load(file)
        with open(y_path, 'rb') as file:
            result_y = pickle.load(file)

        return result.numpy(), result_y.numpy()
# get_features如果路径文件已经存在则读取后直接返回，否则提取model的特征和lable
def get_features(model, train_loader, x_path, y_path,modelname):
    global device
    if (not os.path.exists(x_path)) or (not os.path.exists(y_path)):
        
        if modelname == 'inception_model':
            
            model.fc[3]=nn.Sequential()
            model0 =model
        else:

            model0 = nn.Sequential(*list(model.children())[:-1],  # [b, 512, 1, 1]
                               Flatten(),  # [b, 512, 1, 1] => [b, 512]
                               ).to(device)
        model0.eval()

        for step, (x, y) in enumerate(train_loader):
            x, y = x.to(device), y.to(device)
            with torch.no_grad():
                
            # 计算训练集准确率

                logits = model0(x)
                features =logits  # 获取每个样本的预测标签
                if step == 0:
                    result = features
                    result_y = y;
                else:
                    result = torch.cat([result, features], dim=0)
                    result_y = torch.cat([result_y, y], dim=0)
        result, result_y = result.cpu(), result_y.cpu()
        with open(x_path, 'wb') as file:
            pickle.dump(result, file)
        with open(y_path, 'wb') as file:
            pickle.dump(result_y, file)

        return result.numpy(), result_y.numpy()
    else:
        with open(x_path, 'rb') as file:
            result = pickle.load(file)
        with open(y_path, 'rb') as file:
            result_y = pickle.load(file)

        return result.numpy(), result_y.numpy()


# get_features1 提取model的特征和lable，并返回result.numpy(),result_y.numpy()
def get_features1(model, train_loader):
    global device
    model0 = nn.Sequential(*list(model.children())[:-1],  # [b, 512, 1, 1]
                           Flatten(),  # [b, 512, 1, 1] => [b, 512]
                           ).to(device)
    model0.eval()

    for step, (x, y) in enumerate(train_loader):
        x, y = x.to(device), y.to(device)
        with torch.no_grad():
            features = model0(x)
            if step == 0:
                result = features
                result_y = y;
            else:
                result = torch.cat([result, features], dim=0)
                result_y = torch.cat([result_y, y], dim=0)
    result, result_y = result.cpu(), result_y.cpu()
    return result.numpy(), result_y.numpy()





 

if __name__ == '__main__':
    generativeModel() #获取深度模型
    main() #提取特征，训练CFDE-ELM
